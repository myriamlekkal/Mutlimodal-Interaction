package com.example.tts;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

import android.view.View.OnClickListener;
import android.widget.Button;
import android.view.View;

import android.widget.EditText;

import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;

import android.content.Intent;

import java.util.Locale;

import android.widget.Toast;

public class MyTTS extends Activity implements OnClickListener, OnInitListener {

	private int MY_DATA_CHECK_CODE = 0;
	private TextToSpeech monTTS;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tts);
        
        Button speakButton = (Button)findViewById(R.id.speak);
        speakButton.setOnClickListener(this);   
        
        Intent checkTTSIntent = new Intent();
        checkTTSIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(checkTTSIntent, MY_DATA_CHECK_CODE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_my_tts, menu);
        return true;
    }
    
    public void onClick(View v) {
    	//handle user clicks here
    	EditText enteredText = (EditText)findViewById(R.id.enter);
    	String words = enteredText.getText().toString();
    	speakWords(words);
    	}    
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MY_DATA_CHECK_CODE) {
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                monTTS = new TextToSpeech(this, this);
            }
            else {
                Intent installTTSIntent = new Intent();
                installTTSIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(installTTSIntent);
            }
            }
    }
    
    public void onInit(int initStatus) {
        if (initStatus == TextToSpeech.SUCCESS) {
            if(monTTS.isLanguageAvailable(Locale.US)==TextToSpeech.LANG_AVAILABLE) monTTS.setLanguage(Locale.US);
        }
        else if (initStatus == TextToSpeech.ERROR) {
            Toast.makeText(this, "Sorry! Text To Speech failed...", Toast.LENGTH_LONG).show();
        }
    }

    private void speakWords(String speech) {
    	//implement TTS here
    	monTTS.speak(speech, TextToSpeech.QUEUE_FLUSH, null);
    	}
    
}

